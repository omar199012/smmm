    :root {
   --primary: {{Helper::settings('site_base_color')}};
   --secondary: {{Helper::settings('site_secondary_color')}};
   --tertiary: {{Helper::settings('site_tertiary_color')}};;
     }
